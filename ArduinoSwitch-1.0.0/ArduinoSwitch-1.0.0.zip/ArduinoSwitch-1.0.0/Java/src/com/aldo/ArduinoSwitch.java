package com.aldo;

public class ArduinoSwitch {

    //Se crea una instancia del JFrame para que la interfaz gráfica
    public static void main(String[] args) {
        Window Ventana = new Window();

        Ventana.setVisible(true);

    }

}
